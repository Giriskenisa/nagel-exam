package com.nagel.dto;

public class RefModel {
    private Integer confirmed;
    private Integer recovered;
    private Integer deaths;
    private Integer vaccinated;
    private Integer population;
    private Integer lastConfirmed;
    private String country;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Integer getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(Integer confirmed) {
        this.confirmed = confirmed;
    }

    public Integer getRecovered() {
        return recovered;
    }

    public void setRecovered(Integer recovered) {
        this.recovered = recovered;
    }

    public Integer getDeaths() {
        return deaths;
    }

    public void setDeaths(Integer deaths) {
        this.deaths = deaths;
    }

    public Integer getVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(Integer vaccinated) {
        this.vaccinated = vaccinated;
    }

    public Integer getPopulation() {
        return population;
    }

    public void setPopulation(Integer population) {
        this.population = population;
    }

    public Integer getLastConfirmed() {
        return lastConfirmed;
    }

    public void setLastConfirmed(Integer lastConfirmed) {
        this.lastConfirmed = lastConfirmed;
    }

    @Override
    public String toString() {
        return  "-Country = "+ country +
                "\n-confirmed = " + confirmed +
                "\n-recovered = " + recovered +
                "\n-deaths = " + deaths +
                "\n-vaccinated level in %"+(100*vaccinated)/population+" of total population" +
                "\n-new confirmed cases since last data available is = " + (confirmed > lastConfirmed ? (confirmed-lastConfirmed) : 0) ;
    }
}
