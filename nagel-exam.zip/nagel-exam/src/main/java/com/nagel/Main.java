package com.nagel;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.nagel.dto.RefModel;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;


public class Main {
     private static final String BASE_URL = "https://covid-api.mmediagroup.fr/v1";
     private static final DateTimeFormatter FORMAT_YYYY_MM_DD = DateTimeFormatter.ofPattern("yyyy-MM-dd");
     private static final  Gson GSON = new Gson();


    public static void main(String[] args) throws Exception {
        //Get input From User
        String country = "";
        System.out.println("Please Enter A Country: ");
        Scanner scan = new Scanner(System.in);
        country = scan.next();

        //When input is empty
        if(country.equals("")) {
            throw new Exception("Please Enter A Valid Country.");
        } else {
            RefModel result = getResultAsModel(country);
            System.out.println(result);
        }
    }
    public static RefModel getResultAsModel(String country) throws Exception {

        //When country is null or Empty
        if(country == null || country.equals("")) {
            return new RefModel();
        }

        //Define All Url's
        String casesUrl = BASE_URL.concat("/cases?country=").concat(country);
        String vaccineUrl = BASE_URL.concat("/vaccines?country=".concat(country));
        String historyUrl = BASE_URL.concat("/history?country=".concat(country).concat("&status=confirmed"));

        //Get cases response and store in the caseObj
        JsonObject caseObj =  getData(casesUrl);

        //When caseObj is null return Empty Model and exit the program. Because that means input country is False type or Wrong. No need to get other Url's data. For better Latency.
        if(caseObj == null) {
            return new RefModel();
        }

        //İf country is valid then we can get other information about country.
        JsonObject vaccineObj = getData(vaccineUrl);
        JsonObject historyObj = getData(historyUrl);

        RefModel model = new RefModel();

        //Store results on our RefModel class.
        model.setCountry(caseObj.get("country").getAsString());
        model.setConfirmed(caseObj.get("confirmed").getAsInt());
        model.setRecovered(caseObj.get("recovered").getAsInt());
        model.setDeaths(caseObj.get("deaths").getAsInt());
        model.setPopulation(vaccineObj.get("population").getAsInt());
        model.setVaccinated(vaccineObj.get("people_vaccinated").getAsInt());

        //Get yesterday date for using as key for get latest confirmed data
        LocalDate yesterday = LocalDate.now().minus(1, ChronoUnit.DAYS);

        //Get latest confirmed data from history
        model.setLastConfirmed(historyObj.get("dates").getAsJsonObject().get(FORMAT_YYYY_MM_DD.format(yesterday)).getAsInt());

        return model;
    }

    public static JsonObject getData(String urlAdd) throws IOException {
        URL url = new URL(urlAdd);

        //Create a HttpUrlConnection and connect to it.
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        //Get response code we are expecting 200
        int responseCode = conn.getResponseCode();

        if (responseCode != 200) {
            throw new RuntimeException("HttpResponseCode: " + responseCode);
        } else {
            StringBuilder inline = new StringBuilder();
            try(InputStream is=url.openStream();
                Scanner scanner=new Scanner(is)){
                while (scanner.hasNext()) {
                    inline.append(scanner.nextLine());
                }
            }

            //Get as JsonElement from Stringbuilder and store it in JsonElement object.
            JsonElement jelem = GSON.fromJson(inline.toString(), JsonElement.class);

            //Get 'All' attiributes from JSON and store it in element.
            JsonElement element = jelem.getAsJsonObject().get("All");

            //Control if element is null (input name is wrong or Api returned null or empty JSON.)
            return element == null ? null: element.getAsJsonObject();
        }
    }


}
