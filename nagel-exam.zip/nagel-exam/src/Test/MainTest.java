import com.nagel.Main;

import com.nagel.dto.RefModel;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.runners.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class)
public class MainTest {

    @Test
    public void getData() throws Exception {
        RefModel model = Main.getResultAsModel("France");
        Assert.assertEquals("France", model.getCountry());
    }

    @Test
    public void getPercent() throws Exception {
        RefModel model = Main.getResultAsModel("France");
        model.setVaccinated(10);
        model.setPopulation(100);
        Assert.assertTrue(model.toString().contains("vaccinated level in %10"));
    }

    @Test
    public void nullCountryTest() throws Exception {
        Assert.assertNull(Main.getResultAsModel(null).getCountry());
    }

    @Test
    public void emptyCountryTest() throws Exception {
        Assert.assertNull(Main.getResultAsModel("").getCountry());
    }

    @Test
    public void noneCountryTest() throws Exception {
        Assert.assertNull(Main.getResultAsModel("NotCountry").getCountry());
    }

    @Test
    public void newConfirmedTest() throws Exception {
        RefModel model = Main.getResultAsModel("France");
        model.setConfirmed(3001);
        model.setLastConfirmed(2000);
        Assert.assertTrue(model.toString().contains("new confirmed cases since last data available is = 1001"));
    }

    @Test
    public void newConfirmedTestWhenLess() throws Exception {
        RefModel model = Main.getResultAsModel("France");
        model.setConfirmed(1000);
        model.setLastConfirmed(2000);
        Assert.assertTrue(model.toString().contains("new confirmed cases since last data available is = 0"));
    }


}